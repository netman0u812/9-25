# SSL Decryption Policy — URL/Address Lists by Environment

Source: PAN-OS running-config, all four Panorama managers, 08/31/2026 pull. Every rule below is pulled verbatim from the decryption rulebase (`category` / `destination` / `action` fields) — not summarized or inferred.

Two environments (AZ, RI) share one rulebase pattern; LV-COLO/Meritain share a second, distinct one; Aetna (Middletown/Windsor) has its own separate rulebase per site. Rules are listed top-to-bottom in actual evaluation order.

---

## RI (Rhode Island - DC)

| Rule | Category | Destination | Action |
|---|---|---|---|
| RI-MCAFFEE-TO-INTERNET-PROXY-BYPASS-NO-DECRYPT | any | any | no-decrypt |
| ALL-TO-INTERNET-NO-DECRYPT-ZSCALER | any | Zscaler-EDL | no-decrypt |
| ALL-TO-INTERNET-DECRYPT-CLAUDE | Claude | any | **decrypt** |
| ALL-TO-INTERNET-NO-DECRYPT-CISCO-UMBRELLA | any | Cisco_Umbrella | no-decrypt |
| ALL-TO-INTERNET-NO-DECRYPT-APP-DYNAMICS | any | App-Dynamic, App-Dynamic-NP | no-decrypt |
| ALL-TO-INTERNET-NO-DECRYPT-ILLUMIO | any | G-Illumio-IPs | no-decrypt |
| ALL-TO-INTERNET-NO-DECRYPT-EXCEPTIONS | Adobe, BoxAccess, Business_Partners_URL, Cisco Webex, Cloudflare Storage, CVS Action Center, CVS Health, DICE, Facebook, GIFs, Google Meet, GoToAssist, iCloud, Imgur, Instagram, LeapFile, LinkedIn, LogMeIn, mtalk.google.com, Onedrive, Outlook, Proxy-WG-General, Slack, Splashtop, Syncplicity, TikTok, Twitter, Vimeo, Windows Update, YouTube, Zoom | any | no-decrypt |
| ALL-TO-INTERNET-NO-DECRYPT-GAMBLING | gambling | any | no-decrypt |
| ALL-TO-INTERNET-NO-DECRYPT-SOCIAL-NET | social-networking | any | no-decrypt |
| ALL-TO-INTERNET-NO-DECRYPT-IM | internet-communications-and-telephony | any | no-decrypt |
| ALL-TO-INTERNET-NO-DECRYPT-SHAREWARE | shareware-and-freeware | any | no-decrypt |
| ALL-TO-INTERNET-NO-DECRYPT-STORAGE | online-storage-and-backup | any | no-decrypt |
| ALL-TO-INTERNET-NO-DECRYPT-STREAMING-MEDIA | streaming-media | any | no-decrypt |
| ALL-TO-INTERNET-NO-DECRYPT-WEB-MAIL | internet-communications-and-telephony, web-based-email | any | no-decrypt |
| ALL-TO-INTERNET-NO-DECRYPT-REMOTE-ACCESS | remote-access | any | no-decrypt |
| ALL-TO-INTERNET-DECRYPT-DENIED-CATEGORIES *(last rule)* | abortion, abused-drugs, adult, alcohol-and-tobacco, browser-runtime-attack, command-and-control, compromised-website, copyright-infringement, dating, dynamic-dns, encrypted-dns, extremism, file-converter, gambling, games, grayware, hacking, insufficient-content, internet-communications-and-telephony, malware, marijuana, not-resolved, nudity, online-storage-and-backup, parked, peer-to-peer, phishing, proxy-avoidance-and-anonymizers, Proxy-Zscaler-Blacklist, questionable, ransomware, remote-access, scanning-activity, sex-education, shareware-and-freeware, SOC-Deny-List-Domain, social-networking, streaming-media, swimsuits-and-intimate-apparel, weapons, web-based-email | any | **decrypt** |

**No rule matches Microsoft-Login-SSL-Inspection, Office 365, or any Azure AD sign-in domain.** That traffic falls through to the implicit no-decrypt default.

---

## AZ (Shea - DC)

Identical structure to RI, same 16 rules, same order. Two differences confirmed by direct comparison:

- First rule is named `AZ-MCAFFEE-ZSCALER-TO-INTERNET-PROXY-BYPASS-NO-DECRYPT` (vs. RI's `RI-MCAFFEE-...`) — same fields (category any, destination any, no-decrypt).
- `ALL-TO-INTERNET-NO-DECRYPT-EXCEPTIONS` category list has one extra entry AZ carries that RI doesn't: **DB Fingerprint**. Otherwise the two lists are identical.

Same conclusion: no Microsoft-Login/Office-365 decrypt rule; same implicit no-decrypt fallthrough.

---

## LV-COLO / Meritain (DG_LV_Egress — "ALL-USERS" + "MERITAIN" rules)

Rule names use a generic ALL-USERS-* prefix, not an LV-specific one. This device-group also hosts Meritain-scoped rules, which get materially different (broader) treatment than everyone else.

| Rule | Category | Destination | Action |
|---|---|---|---|
| ALL-USERS-No-Decrpyt | financial-services, government, health-and-medicine | any | no-decrypt |
| ALL-USERS-TO-INTERNET-ZSCALER-NO-DECRYPT | any | Zscaler-EDL | no-decrypt |
| ALL-USERS-TO-INTERNET-DECRYPT-CLAUDE | Claude | any | **decrypt** |
| ALL-USERS-TO-INTERNET-TANIUM-NO-DECRYPT | any | Tanium | no-decrypt |
| ALL-USERS-TO-INTERNET-FIVE9-NO-DECRYPT | any | Five9 | no-decrypt |
| ALL-USERS-TO-INTERNET-APPDYNAMICS-NO-DECRYPT | any | App-Dynamic, App-Dynamic-NP | no-decrypt |
| ALL-USERS-TO-INTERNET-GITHUB-NO-DECRYPT | github | any | no-decrypt |
| ALL-USERS-TO-INTERNET-DOCUSIGN-NO-DECRYPT | docusign.net | any | no-decrypt |
| ALL-USERS-TO-INTERNET-CISCO-UMBRELLA-NO-DECRYPT | any | Cisco_Umbrella | no-decrypt |
| ALL-USERS-WEBEX-NO-DECRYPT | Cisco Webex | any | no-decrypt |
| ALL-USERS-NO-DECRYPT-ILLUMIO | any | G-Illumio-IPs | no-decrypt |
| ALL-TO-INTERNET-WINDOWS-UPDATE-NO-DECRYPT | Windows Update | any | no-decrypt |
| ALL-TO-INTERNET-ONELOGIN-NO-DECRYPT | Onelogin | any | no-decrypt |
| Meritain-To-Internet-Adobe-No-Decryt | Adobe | any | no-decrypt |
| **MERITAIN-TO-INTERNET-MICROSOFT-LOGIN** | **Microsoft-Login-SSL-Inspection** | any | **decrypt** |
| MERITAIN-TO-INTERNET-UNTRUSTED-CERTS-NO-DECRYPT | Untrusted-Certs-SSL-No-Decrypt | any | no-decrypt |
| MERITAIN-TO-INTERNET-MICROSOFT-DEFENDER-NO-DECRYPT | PA-EDL-MS-DEFENDER | any | no-decrypt |
| MERITAIN-TO-INTERNET-PINNED-CERTS-NO-DECRYPT | Pinned-Certs-SSL-No-Decrypt | any | no-decrypt |
| MERITAIN-TO-INTERNET-FILEZILLA-UPDATES-NO-DECRYPT | Filezilla-Updates | any | no-decrypt |
| MERITAIN-TO-INTERNET-FILEZILLA-NO-DECRYPT | any | any | no-decrypt |
| MERITAIN-TO-INTERNET-NO-DECRYPT | Apple, PaloAlto_EDL_o365_URL-shared, SCCM-SSL-No-Decrypt, SIPA-SSL-Allow-No-Decrypt, Splashtop | any | no-decrypt |
| MERITAIN-TO-INTERNET-DECRYPT-ALL | any | any | **decrypt** |
| MERITAIN-TO-INTERNET-DECRYPT-SSH-PROXY | any | any | **decrypt** |

**This is the only environment with a working Microsoft-Login-SSL-Inspection decrypt rule** — and it's scoped to `Meritain-Users-Subnets` only (per the earlier rule-detail check), not the general population. Meritain also gets a full catch-all decrypt (`DECRYPT-ALL`) plus SSH-proxy decrypt — meaningfully more thorough than the ALL-USERS default above it in the same rulebase. Also note: `PaloAlto_EDL_o365_URL-shared` (the actual Office 365 EDL) shows up here as a **no-decrypt** category for Meritain, same pattern as Aetna's explicit Office-365 block.

---

## Aetna — Middletown (LAN-TO-INTERNET rulebase, zones: `Internal_zone` → `External_Zone`)

| Rule | Category | Destination | Action |
|---|---|---|---|
| LAN-TO-INTERNET-NO-DECRYPT-HEALTH-FINANCE *(first rule)* | financial-services, government, health-and-medicine | any | no-decrypt |
| LAN-TO-INTERNET-NO-DECRYPT-ZSCALER | any | CME_Zscaler_EDL | no-decrypt |
| LAN-TO-INTERNET-NO-DECRYPT-CISCO-UMBRELLA | any | Cisco-Umbrella | no-decrypt |
| **LAN-TO-INTERNET-DECRYPT-MS-LOGIN** | **MS Login** | any | **decrypt** |
| LAN-TO-INTERNET-DECRYPT-CLAUDE | Claude | any | **decrypt** |
| MOBILE-DMZ-TO-INTERNET-NO-DECRYPT | any | any | no-decrypt |
| LAN-TO-INTERNET-NO-DECRYPT-FIVE9 | any | Five9_hosts | no-decrypt |
| LAN-TO-INTERNET-NO-DECRYPT-WEBEX | any | Webex-EDL | no-decrypt |
| LAN-TO-INTERNET-NO-DECRYPT-ILLUMIO | any | G-Illumio-IPs | no-decrypt |
| LAN-TO-INTERNET-NO-DECRYPT-APP-DYNAMICS | any | CME-AppDynamics | no-decrypt |
| LAN-TO-INTERNET-NO-DECRYPT-CITRIX | any | Citrix-Online-Servers-IPs | no-decrypt |
| LAN-TO-INTERNET-NO-DECRYPT-CITRIX-CLOUD-CONNECTORS | Citrix-Cloud-Connectors | any | no-decrypt |
| LAN-TO-INTERNET-NO-DECRYPT-MS-DEFENDER | MS-Defender-EDL | any | no-decrypt |
| **LAN-TO-INTERNET-NO-DECRYPT-OFFICE-365** | **MS-Office365-EDL** | any | no-decrypt |
| LAN-TO-INTERNET-NO-DECRYPT-APPDYNAMICS | AppDynamics | any | no-decrypt |
| LAN-TO-INTERNET-NO-DECRYPT-CROWDSTRIKE | Crowdstrike | any | no-decrypt |
| LAN-TO-INTERNET-NO-DECRYPT-CVS-DOMAINS | IMP_Domains | any | no-decrypt |
| LAN-TO-INTERNET-NO-DECRYPT-TANIUM | Clould-Tanium-URLs *(sic — typo in source config)* | any | no-decrypt |
| LAN-TO-INTERNET-NO-DECRYPT-WIN-UPDATES | Windows Update | any | no-decrypt |
| LAN-TO-INTERNET-NO-DECRYPT-GITHUB | Github | any | no-decrypt |
| LAN-TO-INTERNET-NO-DECRYPT-SLACK | Slack | any | no-decrypt |
| LAN-TO-INTERNET-NO-DECRYPT-DOCUSIGN | Docusign | any | no-decrypt |
| LAN-TO-INTERNET-NO-DECRYPT-UNTRUSTED-CERTS | Untrusted Certs | any | no-decrypt |
| LAN-TO-INTERNET-NO-DECRYPT-PINNED-CERTS | Pinned Certs | any | no-decrypt |
| LAN-TO-INTERNET-NO-DECRYPT-ONELOGIN | Onelogin | any | no-decrypt |
| LAN-TO-INTERNET-NO-DECRYPT-ADOBE | Adobe | any | no-decrypt |
| LAN-TO-INTERNET-NO-DECRYPT-SPLASHTOP | Slapshot_I_E_FQDNs *(sic — typo in source config)* | any | no-decrypt |
| LAN-TO-INTERNET-NO-DECRYPT-GOTO | GoToAssist | any | no-decrypt |
| LAN-TO-INTERNET-NO-DECRYPT-APPLE | Apple | any | no-decrypt |
| LAN-TO-INTERNET-NO-DECRYPT-SCCM | SCCM | any | no-decrypt |
| LAN-TO-INTERNET-NO-DECRYPT-SIPA | SIPA | any | no-decrypt |
| LAN-TO-INTERNET-DECRYPT-URL-LIST | ZZ-Decrypt-Websites | any | **decrypt** |
| LAN-TO-INTERNET-DECRYPT-ALLOWED-CATEGORIES | content-delivery-networks, internet-communications-and-telephony, online-storage-and-backup, personal-sites-and-blogs, recreation-and-hobbies, search-engines, social-networking, translation, Youtube | any | **decrypt** |
| LAN-TO-INTERNET-DECRYPT-DENIED-CATEGORIES | abortion, abused-drugs, adult, alcohol-and-tobacco, browser-runtime-attack, command-and-control, compromised-website, copyright-infringement, dating, dynamic-dns, encrypted-dns, extremism, file-converter, gambling, games, grayware, hacking, insufficient-content, internet-communications-and-telephony, malware, marijuana, not-resolved, nudity, online-storage-and-backup, parked, peer-to-peer, phishing, proxy-avoidance-and-anonymizers, questionable, ransomware, remote-access, scanning-activity, sex-education, shareware-and-freeware, social-networking, streaming-media, swimsuits-and-intimate-apparel, weapons, web-based-email | any | **decrypt** |

**Aetna decrypts more broadly than AZ/RI** — 5 decrypt rules here vs. 2 in AZ/RI, including a real MS-Login decrypt rule (unlike AZ/RI, which have none) and a general "Allowed Categories" bucket that AZ/RI don't attempt at all (AZ/RI rely on Zscaler/McAfee for that instead). But Aetna also has the explicit `LAN-TO-INTERNET-NO-DECRYPT-OFFICE-365` rule sitting ahead of the MS-Login decrypt rule in this list — **rule order matters here and should be verified**: if Office-365-categorized traffic (which can include some Microsoft auth endpoints depending on how the EDL is built) matches the Office-365 no-decrypt rule first, it never reaches the MS-Login decrypt rule below it. Worth confirming which category tags actually apply to `login.microsoftonline.com` traffic in this specific EDL before assuming the MS-Login rule is guaranteed to catch it.

## Aetna — Windsor (win-fw-glr rulebase)

Same structural pattern as Middletown, confirmed via rule-name mirroring, but with a longer no-decrypt exception list (39 total rules vs. Middletown's 34) — 5 decrypt rules in both. Full category-by-category detail for Windsor's additional exceptions was not extracted in this pass; flag if you want that pulled too.

---

## Shared destination/EDL objects worth knowing across environments

- **Zscaler-EDL** (AZ/RI) vs **CME_Zscaler_EDL** (Aetna) — different EDL objects per estate, not shared.
- **G-Illumio-IPs**, **App-Dynamic/App-Dynamic-NP**, **Cisco_Umbrella** — same or near-same object names reused across AZ/RI and LV-COLO.
- **PaloAlto_EDL_o365_URL-shared** — the actual Palo Alto-maintained Office 365 EDL — appears explicitly in the Meritain no-decrypt list; Aetna's equivalent uses its own named category `MS-Office365-EDL` instead of this shared EDL object.
- **"MS Login" vs "Microsoft-Login-SSL-Inspection"** — these are two *differently named* category objects, one in the Aetna Panorama, one in the AZ/RI/LV Panorama. They are almost certainly intended to serve the same purpose (identifying Microsoft/Azure AD sign-in traffic) but are separately maintained objects — worth checking whether their actual domain/URL contents match, since a drift between the two would mean "MS Login" catches different traffic than "Microsoft-Login-SSL-Inspection" does.
